class Person {
  // Shared properties and behavior for everyone in the hierarchy.
  String name;
  int age;

  Person(this.name, this.age);

  void introduce() {
    print("I'm $name, $age years old");
  }
}

// Student inherits Person's name, age, and introduce method.
class Student extends Person {
  // Additional information specific to students.
  String studentId;
  double gpa;

  // Initialize inherited fields with the superclass constructor.
  Student(String name, int age, this.studentId, this.gpa) : super(name, age);

  // Replace Person's introduction with student-specific information.
  @override
  void introduce() {
    print('Student: $name, ID: $studentId, GPA: $gpa');
  }
}

// GraduateStudent inherits Student fields and adds a thesis topic.
class GraduateStudent extends Student {
  String thesisTopic;

  // Forward inherited values through the constructor chain.
  GraduateStudent(String name, int age, String id, double gpa, this.thesisTopic)
    : super(name, age, id, gpa);

  // Override again to provide graduate-specific behavior.
  @override
  void introduce() {
    print('Graduate: $name, Topic: $thesisTopic');
  }
}

void main(List<String> args) {
  // A parent-typed list can contain Person and its subclasses.
  List<Person> people = 
  [
    Student('Ahmet', 20, 'S123456', 3.5),
    GraduateStudent('Mehmet', 25, 'G789012', 3.8, 'Machine Learning'),
    Person('Ayşe', 30),
  ];

  for (var person in people) {
    person.introduce(); // Runtime type selects the appropriate override.
  }
}
