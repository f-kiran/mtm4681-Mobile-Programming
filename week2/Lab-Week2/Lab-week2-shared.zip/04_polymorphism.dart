class Animal {
  // Subclasses can override this default behavior.
  void makeSound() {
    print('Some generic animal sound');
  }
}

class Dog extends Animal {
  // Override the inherited method with Dog-specific behavior.
  @override
  void makeSound() {
    print('Woofff!');
  }
}

class Cat extends Animal {
  // Override the inherited method with Cat-specific behavior.
  @override
  void makeSound() {
    print('Meowww!');
  }
}

void main(List<String> args) {
  // The variables use the parent type but refer to different subclasses.
  Animal dog = Dog();
  Animal cat = Cat();

  // Runtime dispatch calls each object's overridden implementation.
  dog.makeSound();
  cat.makeSound();
}
