class BankAccount {
  // Leading underscores make these fields private to this Dart library.
  String _accountNumber;
  double _balance;

  BankAccount(this._accountNumber, this._balance);

  void deposit(double amount) {
    // Reject zero or negative deposits to protect the account balance.
    if (amount > 0) {
      _balance += amount;
      print(
        'Deposited $amount to account $_accountNumber. New balance: $_balance',
      );
    }
  }

  // Expose the balance for reading without allowing direct assignment.
  double get balance => _balance;
}

void main(List<String> args) {
  var account = BankAccount('123456', 1000.0);
  account.deposit(500.0);
  print('Balance: ${account.balance}'); // Read balance through its getter.
}
