class Student {
  // Instance fields store data for each Student object.
  String name;
  int age;

  // The this.field parameters assign values to the fields.
  Student(this.name, this.age);

  // Methods define behavior that a Student object can perform.
  void displayInfo() {
    print('Student: $name, Age: $age');
  }
}

void main(List<String> args) {
  var student = Student('Ali', 20);
  var student1 = Student('Mehmet', 30);
  student.displayInfo(); // Call the method on this Student instance.
  student1.displayInfo(); 
}
