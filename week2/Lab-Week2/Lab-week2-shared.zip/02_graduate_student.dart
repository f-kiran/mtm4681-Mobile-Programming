class Person {
  // These fields are common to all people.
  String name;
  int age;

  Person(this.name, this.age);
}

// A graduate student inherits the shared fields from Person.
class GraduateStudent extends Person {
  // These fields are specific to graduate students.
  String major;
  double gpa;

  // Pass the inherited values to the Person constructor.
  GraduateStudent(String name, int age, this.major, this.gpa)
    : super(name, age);

  void displayInfo() {
    print('Graduate student: $name, Major: $major, GPA: $gpa');
  }
}

void main(List<String> args) {
  var grad = GraduateStudent('Zeynep', 25, 'Computer Eng.', 3.75);
  grad.displayInfo(); // Uses inherited name plus the graduate-specific fields.
}
