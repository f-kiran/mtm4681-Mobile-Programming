// An interface declares a behavior that implementing classes must provide.
abstract class Drawable {
  void draw();
}

// Circle implements Drawable and supplies its required draw behavior.
class Circle implements Drawable {
  double radius;

  // Keep the radius so draw() can describe this circle.
  Circle(this.radius);

  @override
  void draw() {
    print('Drawing a circle with radius $radius');
  }
}

// Square provides the same interface with shape-specific data and behavior.
class Square implements Drawable {
  double side;

  Square(this.side);

  @override
  void draw() {
    print('Drawing a square with side $side');
  }
}

void main(List<String> args) {
  // Different concrete types can share a list through a common interface.
  List<Drawable> shapes = [Circle(5), Square(3)];

  for (var shape in shapes) {
    // Runtime dispatch calls the draw implementation for each shape.
    shape.draw();
  }
}
