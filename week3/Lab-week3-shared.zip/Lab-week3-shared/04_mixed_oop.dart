// Implementers must define both a sound and a species getter.
abstract class Animal {
  void makeSound();
  String get species;
}

// A separate interface represents the ability to play.
abstract class Pet {
  void play();
}

// Cat inherits Animal's contract and implements the Pet capability.
class Cat extends Animal implements Pet {
  @override
  void makeSound() {
    print('Cat meows');
  }

  @override
  void play() {
    print('Cat plays with yarn');
  }

  @override
  String get species => 'Feline';
}

void main(List<String> args) {
  var cat = Cat();
  // Cat fulfills the behavior required by both contracts.
  cat.makeSound();
  cat.play();
  print('Species: ${cat.species}');
}
