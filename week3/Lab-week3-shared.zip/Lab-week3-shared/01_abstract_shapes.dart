// Abstract classes define required behavior without providing every implementation.
abstract class Shape {
  double area();
  double perimeter();
}

// Rectangle inherits the Shape contract and implements both calculations.
class Rectangle extends Shape {
  double width;
  double height;

  // Constructor parameters initialize the rectangle's dimensions.
  Rectangle(this.width, this.height);

  // A rectangle's area is width multiplied by height.
  @override
  double area() => width * height;

  // A rectangle has two sides of each dimension.
  @override
  double perimeter() => 2 * (width + height);
}

// Circle provides its own implementations of the Shape contract.
class Circle extends Shape {
  double radius;

  // The radius is needed by both circle calculations.
  Circle(this.radius);

  @override
  double area() => 3.14 * radius * radius;

  @override
  double perimeter() => 2 * 3.14 * radius;
}

void main(List<String> args) {
  Rectangle rect = Rectangle(5, 3);
  Circle circle = Circle(4);

  // Each concrete shape calculates its own area and perimeter.
  print('Rectangle area: ${rect.area()}, perimeter: ${rect.perimeter()}');
  print('Circle area: ${circle.area()}, perimeter: ${circle.perimeter()}');
}
