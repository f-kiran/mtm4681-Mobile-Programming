// Abstract base class provides shared vehicle state and behavior contracts.
abstract class Vehicle {
  String brand;
  double speed;

  Vehicle(this.brand, this.speed);

  // Subclasses must define how acceleration and top speed work.
  void accelerate(double increment);
  double getTopSpeed();
}

// This interface describes capabilities specific to electric vehicles.
abstract class ElectricVehicle {
  int get batteryLevel;
  set batteryLevel(int value);
  void charge();
}

// ElectricCar inherits Vehicle implementation and implements the electric API.
class ElectricCar extends Vehicle implements ElectricVehicle {
  // Implements the interface's required battery property.
  @override
  int batteryLevel;

  // Initialize the battery and pass common fields to Vehicle.
  ElectricCar(String brand, double speed, this.batteryLevel)
    : super(brand, speed);

  @override
  void accelerate(double increment) {
    // Increase current speed by the requested amount.
    speed += increment;
    print('Accelerated. New speed: $speed');
  }

  @override
  double getTopSpeed() => speed * 1.5;

  @override
  void charge() {
    // Charging sets the battery to full capacity.
    batteryLevel = 100;
    print('Car is fully charged');
  }

  @override
  // Provide a readable summary of the car's current state.
  String toString() =>
      '$brand Electric Car (Speed: $speed, Battery: $batteryLevel%)';
}

void main(List<String> args) {
  var car = ElectricCar('Tesla', 60.0, 75);
  print(car.toString());

  // Exercise acceleration, top-speed calculation, and charging.
  car.accelerate(20);
  print('Top speed: ${car.getTopSpeed()}');
  car.charge();
}
