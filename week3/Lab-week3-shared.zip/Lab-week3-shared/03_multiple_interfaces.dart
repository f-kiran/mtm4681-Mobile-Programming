// Each interface describes one capability.
abstract class Flyable {
  void fly();
}

abstract class Swimmable {
  void swim();
}

// Duck implements both interfaces and must provide both methods.
class Duck implements Flyable, Swimmable {
  @override
  void fly() {
    print('Duck is flying');
  }

  @override
  void swim() {
    print('Duck is swimming');
  }
}

void main(List<String> args) {
  var duck = Duck();
  // The same object supports both declared capabilities.
  duck.fly();
  duck.swim();
}
