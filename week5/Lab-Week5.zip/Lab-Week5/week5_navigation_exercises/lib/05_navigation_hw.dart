
// Exercise 5 — Navigation Challenge
// Build a full app flow:
// 1. Home screen with 3 buttons (Profile, Shopping List, Notes)
// 2. Each button navigates to its own screen
// 3. From each screen you can go back to home
// 4. Use both push/pop and named routes
