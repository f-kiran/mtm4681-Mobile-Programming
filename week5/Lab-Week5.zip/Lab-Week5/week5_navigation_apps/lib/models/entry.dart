class Entry {
  final String id;
  final String expr;
  final double result;

  Entry({
    required this.id,
    required this.expr,
    required this.result,
  });

  factory Entry.generate({required String expr, required double result}) {
    return Entry(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      expr: expr,
      result: result,
    );
  }
}
