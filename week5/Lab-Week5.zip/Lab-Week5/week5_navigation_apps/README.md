# Lab Week 4 - Complete Sample App

## Overview
This is a **complete, working** Calculator UI demonstrating:
- ✅ Material Design (Scaffold, AppBar, Themes)
- ✅ Stateful widgets with `setState`
- ✅ Layout widgets (Row, Column, GridView, ListView)
- ✅ Form validation with RegExp
- ✅ Responsive design (SingleChildScrollView)
- ✅ Dark mode support
- ✅ History management with Dismissible

## Features

### 1. Display
- Right-aligned expression text with `FittedBox` to prevent overflow
- Large, bold font (displayMedium style)
- Uses theme colors for contrast

### 2. Expression Field
- TextField with hint "e.g., 2+3*4"
- Clear button (C) and Backspace button (⌫)
- TextEditingController for state management

### 3. Calculator Keypad
- `GridView.count(crossAxisCount: 4)` - 4 columns
- 16 buttons: 0-9, ., +, −, ×, ÷, =
- Operators styled in primary color; numbers in secondary
- Equal widths via grid layout

### 4. History List
- `ListView.builder` - lazy renders entries
- Each entry shows: expression + result = value
- `Dismissible` for swipe-to-delete with ValueKey
- Tap to recall expression; copy button for result
- Empty state message when no history

### 5. Theme & Responsive
- Uses `colorSchemeSeed: Colors.indigo` for Material 3
- Dark theme automatically supported
- `SingleChildScrollView` wrapper prevents keyboard overlap
- `Theme.of(context)` colors instead of hard-coded hex

## Project Structure
```
complete_sample_app/
├── pubspec.yaml
├── README.md
└── lib/
    ├── main.dart          (entire app)
    └── models/
        └── entry.dart     (history entry model)
```

## Running the Complete App
```bash
cd complete_sample_app
flutter pub get
flutter run

# Test dark mode
# In emulator: Settings → Display → Dark theme (or system follows OS)

# Test landscape
# Press Ctrl+Left (or Cmd+Left on Mac) in emulator
```

## Code Highlights

### State Management
```dart
// In _CalculatorScreenState
String expr = '';
List<Entry> history = [];
late TextEditingController _exprController;

// In initState: set up controller
// In dispose: clean up controller - CRITICAL to avoid memory leak
```

### Entry Model
```dart
// Generates unique ID using timestamp
factory Entry.generate({required String expr, required double result}) {
  return Entry(
    id: DateTime.now().millisecondsSinceEpoch.toString(),
    expr: expr,
    result: result,
  );
}
```

### GridView Keypad
```dart
GridView.count(
  crossAxisCount: 4,
  shrinkWrap: true,
  physics: const NeverScrollableScrollPhysics(),
  childAspectRatio: 1.0,  // Square buttons
  children: [/* buttons */],
)
```

### History with Dismissible
```dart
Dismissible(
  key: ValueKey(entry.id),  // IMPORTANT: unique key per item
  onDismissed: (_) => onDelete(i),
  child: HistoryTile(...),
)
```

### Widget Decomposition (const-friendly)
- `Display` - stateless, displays expr
- `ExpressionField` - reusable input row
- `Keypad` - grid of buttons
- `KeyButton` - single button (const!)
- `HistoryList` - full history section
- `HistoryTile` - single history entry (const!)

## Key Patterns

### 1. State Lifting
State (`expr`, `history`) lives in `CalculatorScreen` (root).
Child widgets are stateless; callbacks pass data up.

```
CalculatorScreen (state)
├── Display(expr)        ← read-only
├── ExpressionField()    ← calls onClear, onBackspace
├── Keypad()             ← calls onKeyPressed, onEquals
└── HistoryList()        ← calls onDelete, onSelect
```

### 2. TextEditingController Lifecycle
```dart
@override
void initState() {
  _exprController = TextEditingController(text: expr);
}

@override
void dispose() {
  _exprController.dispose();  // ← Must do this!
  super.dispose();
}
```

### 3. Validation (Simple Version)
```dart
void calculate() {
  if (expr.isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(...);
    return;
  }
  // In real app: parse and evaluate expr using Week 3 solver
  final entry = Entry.generate(expr: expr, result: 42.0);  // Stub
  setState(() { ... });
}
```

### 4. Theme Colors
```dart
// Instead of: Color(0xFF5F5F5F)
// Use: Theme.of(context).colorScheme.primary

ElevatedButton(
  style: ElevatedButton.styleFrom(
    backgroundColor: isOperator 
        ? Theme.of(context).colorScheme.primary
        : Theme.of(context).colorScheme.secondary,
  ),
)
```

## Testing Checklist

- [ ] Tap numbers → display updates (right-aligned)
- [ ] Long expression → FittedBox shrinks text, no overflow
- [ ] C button → clears expression
- [ ] ⌫ button → deletes last character
- [ ] = button → adds entry to history, clears display
- [ ] Tap history entry → recalls expression
- [ ] Swipe history entry → dismisses (slides away, deleted)
- [ ] Empty history → shows "No computations yet"
- [ ] Copy button → SnackBar "Copied"
- [ ] **Dark mode**: Settings → Dark, verify contrast
- [ ] **Landscape**: Rotate, no overflow stripes
- [ ] **flutter analyze**: zero errors/warnings

## Extending the App (Week 5+)

### Add Plotter Screen
- Create `PlotterScreen` with form (min, max, step, f(x))
- Use `LayoutBuilder` for side-by-side on wide, stacked on phone
- Push via `Navigator.push` or `go_router`

### Integrate Week 3 Solver
- Replace `result: 42.0` with actual evaluation
- Catch exceptions → show ErrorCard widget
- Use `FutureBuilder` if solver is async

### Persist History
- Save to local database (Hive, Week 8) or Firebase (Week 9)
- Load in `initState`

### Charts
- Add `fl_chart` package; visualize y=f(x) over [min, max, step]
- Legend + responsive canvas

## Troubleshooting

| Issue | Cause | Fix |
|-------|-------|-----|
| Yellow overflow stripes | Unbounded Row/Column | Already wrapped in `SingleChildScrollView` |
| Text doesn't shrink | FittedBox not working | Reduce font size or check parent constraints |
| Controller error on hot-reload | dispose not called | Verify `@override void dispose()` |
| Wrong history deleted | No ValueKey | Each Dismissible must have unique `ValueKey(id)` |
| Dark mode hard to read | Hard-coded colors | Use `colorScheme.*` properties |

## Further Reading

- [Flutter Widget Catalog](https://docs.flutter.dev/ui/widgets)
- [Layouts Codelab](https://docs.flutter.dev/codelabs/layout-basics)
- [Form validation](https://docs.flutter.dev/codelabs/form-validation)
- [Material 3 Color System](https://m3.material.io/styles/color/overview)

---

**Reference:** Week 4 Slides - Materials, Lists, Forms; adapted for Calculator lab (plotter + multi-screen in Week 5).
