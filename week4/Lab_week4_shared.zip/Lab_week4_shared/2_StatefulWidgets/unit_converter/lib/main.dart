import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late double _numberFrom;
  late String _selectedFromMeasure;
  late String _selectedToMeasure;
  late String _resultMessage;

  final TextStyle inputStyle = TextStyle(
    fontSize: 16,
    color: Colors.blue[900],
  );

  final TextStyle labelStyle = TextStyle(
    fontSize: 24,
    color: Colors.grey[700],
  );

  final List<DropdownMenuItem<String>> measuresDropDownMenuItems = const [
    DropdownMenuItem(value: 'meters', child: Text('meters')),
    DropdownMenuItem(value: 'kilometers', child: Text('kilometers')),
    DropdownMenuItem(value: 'grams', child: Text('grams')),
    DropdownMenuItem(value: 'kilograms', child: Text('kilograms')),
  ];

  final Map<String, int> _measuresMap = {
    'meters': 0,
    'kilometers': 1,
    'grams': 2,
    'kilograms': 3,
  };

  final Map<String, List> _formulas = {
    '0': [1, 0.001, 0, 0],
    '1': [1000, 1, 0, 0],
    '2': [0, 0, 1, 0.001],
    '3': [0, 0, 1000, 1]
  };

  @override
  void initState() {
    _numberFrom = 0;
    _selectedFromMeasure = measuresDropDownMenuItems.first.value.toString();
    _selectedToMeasure = measuresDropDownMenuItems.first.value.toString();
    _resultMessage = '';
    super.initState();
  }

  void convert(double value, String from, String to) {
    int nFrom = _measuresMap[from] ?? -1;
    int nTo = _measuresMap[to] ?? -1;
    if (nFrom != -1 && nTo != -1) {
      var multiplier = _formulas[nFrom.toString()]?.elementAt(nTo);
      var result = value * double.parse(multiplier.toString());
      setState(() {
        if (result == 0) {
          _resultMessage = 'This conversion cannot be performed';
        } else {
          _resultMessage = "$value $from = $result $to";
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Measures Converter",
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.deepPurple,
          title: const Text("Measures Converter"),
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const Spacer(),
              Text('Value', style: labelStyle),
              const Spacer(),
              TextField(
                style: inputStyle,
                decoration: const InputDecoration(
                    hintText: "Please insert the measure to be converted"),
                onChanged: (text) {
                  var readValue = double.tryParse(text);
                  if (readValue != null) {
                    setState(() {
                      _numberFrom = readValue;
                    });
                  }
                },
              ),
              const Spacer(),
              Text('From', style: labelStyle),
              DropdownButton(
                isExpanded: true,
                items: measuresDropDownMenuItems,
                value: _selectedFromMeasure,
                onChanged: (value) {
                  setState(() {
                    _selectedFromMeasure = value.toString();
                  });
                },
              ),
              const Spacer(),
              Text('To', style: labelStyle),
              DropdownButton(
                isExpanded: true,
                items: measuresDropDownMenuItems,
                value: _selectedToMeasure,
                onChanged: (value) {
                  setState(() {
                    _selectedToMeasure = value.toString();
                  });
                },
              ),
              const Spacer(flex: 2),
              ElevatedButton(
                child: Text('Convert', style: inputStyle),
                onPressed: () {
                  if (_selectedFromMeasure.isEmpty ||
                      _selectedToMeasure.isEmpty) {
                    return;
                  } else {
                    convert(
                        _numberFrom, _selectedFromMeasure, _selectedToMeasure);
                  }
                },
              ),
              const Spacer(flex: 2),
              Text(_resultMessage.toString(), style: labelStyle),
              const Spacer(flex: 8),
            ],
          ),
        ),
      ),
    );
  }
}
