import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'hello YTU',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color.fromARGB(255, 226, 110, 9)),
        useMaterial3: true,
      ),
      home: const TravelHomePage(),
    );
  }
}

class TravelHomePage extends StatelessWidget {
  const TravelHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hello YTU AppBar'),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(5),
        child: Center(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(10),
                child: Text(
                  'hello YTU',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue.shade800,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(10),
                child: Text(
                  'Discover the YTU World at Davut Pasha Campus, where innovation meets tradition. Explore our vibrant community, cutting-edge research, and rich cultural heritage. Join us in shaping the future at YTU!',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.deepPurpleAccent,
                  ),
                  textAlign: TextAlign.justify,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(15),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.network(
                    'https://ogi.yildiz.edu.tr/sites/ogi.yildiz.edu.tr/files/2026-02/turkiyenin-yildizi-ytu.jpg',
                    height: 350,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    webHtmlElementStrategy: WebHtmlElementStrategy.fallback, // Use fallback strategy for web
                    errorBuilder: (context, error, stackTrace) => Container(
                      height: 350,
                      width: double.infinity,
                      color: Colors.deepPurple.shade50,
                      alignment: Alignment.center,
                      child: const Text('YTU photo is unavailable.'),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(15),
                child: ElevatedButton(
                  onPressed: () => _showContactDialog(context),
                  child: const Text('Contact Us'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

void _showContactDialog(BuildContext context) {
  showDialog<void>(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('Contact Us'),
      content: const Text('Email us at hello@world.com'),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
      ],
    ),
  );
}
